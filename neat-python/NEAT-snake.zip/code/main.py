import pygame
from snake import Game
import neat
import os
import pickle
import math

class SnakeGame:
    def __init__(self, screen, width, height):
        self.game = Game(screen, width, height)
        self.game_logic = self.game.game_logic
    
    def get_direction_keys_from_action(self, action):
        """
        Convert relative action (0=left, 1=straight, 2=right) to absolute direction keys.
        Uses current snake direction to compute the new direction.
        Returns keys tuple with the appropriate movement key set to True.
        """
        # Current direction of snake
        dx, dy = self.game_logic.direction
        
        # Map current direction to left/right turns
        if (dx, dy) == (1, 0):  # moving right
            if action == 0:  # turn left
                new_dir = (0, -1)  # up
            elif action == 1:  # straight
                new_dir = (1, 0)  # right
            else:  # turn right
                new_dir = (0, 1)  # down
        elif (dx, dy) == (-1, 0):  # moving left
            if action == 0:  # turn left
                new_dir = (0, 1)  # down
            elif action == 1:  # straight
                new_dir = (-1, 0)  # left
            else:  # turn right
                new_dir = (0, -1)  # up
        elif (dx, dy) == (0, -1):  # moving up
            if action == 0:  # turn left
                new_dir = (-1, 0)  # left
            elif action == 1:  # straight
                new_dir = (0, -1)  # up
            else:  # turn right
                new_dir = (1, 0)  # right
        elif (dx, dy) == (0, 1):  # moving down
            if action == 0:  # turn left
                new_dir = (1, 0)  # right
            elif action == 1:  # straight
                new_dir = (0, 1)  # down
            else:  # turn right
                new_dir = (-1, 0)  # left
        else:
            new_dir = (1, 0)  # default to right
        
        # Convert direction to key
        # Create a tuple large enough for pygame key indices (pygame.K_ESCAPE = 27, pygame.K_z = 122, etc.)
        keys_dict = {pygame.K_w: False, pygame.K_a: False, pygame.K_s: False, pygame.K_d: False}
        if new_dir == (1, 0):
            keys_dict[pygame.K_d] = True
        elif new_dir == (-1, 0):
            keys_dict[pygame.K_a] = True
        elif new_dir == (0, -1):
            keys_dict[pygame.K_w] = True
        elif new_dir == (0, 1):
            keys_dict[pygame.K_s] = True
        
        # Convert dict to tuple for game_logic.update() which expects keys to be indexable by key code
        keys_tuple = [False] * 512  # Large enough for all pygame key codes
        for key_code, pressed in keys_dict.items():
            keys_tuple[key_code] = pressed
        
        return tuple(keys_tuple)
        
    def test_ai(self, genome, config):
        net = neat.nn.FeedForwardNetwork.create(genome, config)
        
        run = True
        clock = pygame.time.Clock()
        while run:
            clock.tick(10)  # Limit to 60 FPS
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
                    break
                
            inputs = (
                list(self.game_logic.get_direction(as_onehot=False)) +
                list(self.game_logic.get_immediate_danger()) +
                list(self.game_logic.get_relative_apple_position(normalize=True))
            )
            
            # Get neural network output (3 values: left, straight, right)
            output = net.activate(inputs)
            
            # Decide movement: pick argmax of 3 actions (left=0, straight=1, right=2)
            action = output.index(max(output)) if len(output) >= 3 else 1
            
            # Convert relative action to keys using current direction
            keys = self.get_direction_keys_from_action(action)
            
            # Create proper input_data dictionary for game_logic.update()
            input_data = {
                'keys': keys,
                'mouse_pos': (0, 0),
                'mouse_buttons': (False, False, False)
            }
            
            self.game_logic.update(input_data)

            # Render and display
            from snake.snake import CELL_SIZE
            self.game.renderer.render(self.game.screen, self.game_logic.grid, CELL_SIZE)
            pygame.display.update()      
        # Print final score when the run finishes
        print("Test run finished. Final score:", self.game_logic.score)
        pygame.quit() 
        
    def train_ai(self, genome, config):
        #net = neat.nn.FeedForwardNetwork.create(genome, config)
        net = neat.nn.RecurrentNetwork.create(genome, config)
        
        run = True
        steps = 0
        steps_since_apple = 0
        max_steps_without_apple = 1000  # Stop if no apple eaten in this many steps
        min_distance_to_apple = float('inf')  # Track closest approach to apple
        previous_distance = float('inf')  # Track distance from previous step for proximity rewards/penalties
        proximity_score = 0  # Accumulate proximity-based fitness during training
        
        while run:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    quit()
            
            # Gather inputs for the neural network
            inputs = (
                list(self.game_logic.get_direction(as_onehot= False)) +
                list(self.game_logic.get_immediate_danger()) +
                list(self.game_logic.get_relative_apple_position(normalize=True))
            )
            
            # Get neural network output (3 values: left, straight, right)
            output = net.activate(inputs)
            
            # Decide movement: pick argmax of 3 actions (left=0, straight=1, right=2)
            action = output.index(max(output)) if len(output) >= 3 else 1
            
            # Convert relative action to keys using current direction
            keys = self.get_direction_keys_from_action(action)
            
            # Create proper input_data dictionary for game_logic.update()
            input_data = {
                'keys': keys,
                'mouse_pos': (0, 0),
                'mouse_buttons': (False, False, False)
            }
            
            # Track score before update to detect apple eating
            score_before = self.game_logic.score
            
            # Update game logic with the constructed input
            self.game_logic.update(input_data)
            
            # Track distance to apple for proximity bonus
            dx, dy = self.game_logic.get_relative_apple_position(normalize=False)
            distance_to_apple = abs(dx) + abs(dy)  # Manhattan distance
            if distance_to_apple < min_distance_to_apple:
                min_distance_to_apple = distance_to_apple
            
            # Proximity rewards/penalties: reward for moving closer, punish for moving away
            if previous_distance != float('inf'):
                if distance_to_apple < previous_distance:
                    # Moving closer to apple: +1.5 points per cell
                    proximity_score += (previous_distance - distance_to_apple) * 1.5
                else:
                    # Moving away from apple: -1 point per cell (asymmetric as requested)
                    proximity_score -= (distance_to_apple - previous_distance) * 1.0
            
            previous_distance = distance_to_apple
            
            # Check if an apple was eaten
            if self.game_logic.score > score_before:
                steps_since_apple = 0  # Reset counter
                previous_distance = float('inf')  # Reset for next apple
                min_distance_to_apple = float('inf')  # Reset for next apple
            else:
                steps_since_apple += 1
            
            # Render the game
            #from snake.snake import CELL_SIZE
            #self.game.renderer.render(self.game.screen, self.game_logic.grid, CELL_SIZE)
            #pygame.display.update()
            
            steps += 1
            
            # Check if game is over (death or timeout without eating)
            if not self.game_logic.isalive:
                self.calc_fitness(genome, self.game_logic.score, steps, min_distance_to_apple, proximity_score)
                break
            elif steps_since_apple > max_steps_without_apple:
                # Timeout: snake hasn't eaten in too long, likely spinning
                self.calc_fitness(genome, self.game_logic.score, steps, min_distance_to_apple, proximity_score)
                break
            
    
    def calc_fitness(self, genome, score, steps, min_distance_to_apple=float('inf'), previous_distance=float('inf')):
        
    # --- Tunable hyperparameters ---
        alpha = 1.25       # superlinear scaling for apples (1.2–1.3 is typical)
        A = 300.0          # base multiplier for the apple term

        target_spa = 30.0  # target steps per apple (tune per board/speed)
        B = 200.0          # max magnitude for efficiency bonus/penalty
        g = 0.75           # sensitivity of efficiency tanh (higher = more sensitive)

        C = 150.0          # proximity bonus scale (bounded inverse distance)
        D = 8.0            # small bonus for moving closer than last distance

        step_cap = 1500    # cap contribution of survival steps (prevents stalling rewards)
        E = 0.02           # survival scaling (very small)

        Z = 120.0          # penalty if zero apples eaten

        # --- Base apple reward (primary goal) ---
        base = A * (score ** alpha)

        # # --- Efficiency bonus: compare steps-per-apple to target, bounded ---
        # if score > 0:
        #     steps_per_apple = steps / score
        #     efficiency_ratio = target_spa / max(steps_per_apple, 1e-6)
        #     # positive if faster than target, negative if slower, bounded by tanh
        #     eff = B * math.tanh(g * (efficiency_ratio - 1.0))
        # else:
        #     eff = 0.0

        # # --- Proximity bonus (bounded inverse distance) ---
        # if math.isfinite(min_distance_to_apple) and min_distance_to_apple > 0:
        #     prox = C * (1.0 / (1.0 + min_distance_to_apple))
        # else:
        #     prox = 0.0

        # # --- Bonus for moving closer (small) ---
        # moved_closer = D if previous_distance > min_distance_to_apple else 0.0

        # # --- Survival (small, capped) ---
        # survival = E * min(steps, step_cap)

        # --- Penalty for doing nothing ---
        zero_pen = -Z if score == 0 else 0.0

        # --- Combine ---
        fitness = base + zero_pen # + prox + moved_closer + survival + eff 

        # Optional: ensure fitness is not negative (can help early learning stability)
        fitness = max(fitness, -Z)

        genome.fitness = fitness
        return fitness


        
def eval_genomes(genomes, config):
    width, height = 588, 595
    screen = pygame.display.set_mode((width, height))
    
    for i, (genome_id, genome) in enumerate(genomes):
        genome.fitness = 0  # Initialize fitness
        game = SnakeGame(screen, width, height)
        game.train_ai(genome, config)
        
def run_neat(config):
    p = neat.Checkpointer.restore_checkpoint('neat-checkpoint-2274') # to resume from a checkpoint
    #p = neat.Population(config)
    p.add_reporter(neat.StdOutReporter(True))
    stats = neat.StatisticsReporter()
    p.add_reporter(stats)
    p.add_reporter(neat.Checkpointer(25))
    
    winner = p.run(eval_genomes, 1) # number of generations
    
    with open('best_genome.pkl', 'wb') as f:
        pickle.dump(winner, f)
    
def test_ai(config):
    width, height = 588, 595
    screen = pygame.display.set_mode((width, height))
    with open('best_genome.pkl', 'rb') as f:
        winner = pickle.load(f)
        
    game = SnakeGame(screen, width, height)
    game.test_ai(winner, config)        
        
if __name__ == "__main__":
    local_dir = os.path.dirname(__file__)
    config_path = os.path.join(local_dir, 'config.txt')
    
    config = neat.Config(neat.DefaultGenome, neat.DefaultReproduction,
                         neat.DefaultSpeciesSet, neat.DefaultStagnation,
                         config_path)
    #run_neat(config)
    test_ai(config)
    
    




