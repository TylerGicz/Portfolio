----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/01/2025 12:45:41 AM
-- Design Name: 
-- Module Name: mux2to1_32bit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


ENTITY mux2to1_32bit IS
	PORT (
        in0, in1 : IN STD_LOGIC_VECTOR(31 downto 0);
        sel : in STD_LOGIC;
		mux_out : OUT STD_LOGIC_VECTOR(31 downto 0)
  );
END mux2to1_32bit;


ARCHITECTURE dataflow OF mux2to1_32bit IS	

BEGIN
	mux_out <= in0 WHEN sel = '0' ELSE in1;
END dataflow ;