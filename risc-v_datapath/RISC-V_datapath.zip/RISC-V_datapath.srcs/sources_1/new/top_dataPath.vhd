----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/30/2025 10:17:11 PM
-- Design Name: 
-- Module Name: top_dataPath - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity top_dataPath is
    port (
        CLK   : in std_logic;
        Reset : in std_logic;
        -- for TB
        PC_out_tb : out std_logic_vector(31 downto 0);  -- expose PC
        MUX3_out_tb : out std_logic_vector(31 downto 0); -- expose mux3 output
        INSTRUCTION_tb : out std_logic_vector(31 downto 0); --expose instruction output
        ALU_out_tb : out std_logic_vector(31 downto 0); -- expose alu 
        regFile_outData1_tb : out std_logic_vector(31 downto 0);
        regFile_outData2_tb : out std_logic_vector(31 downto 0);
        mux1_out_tb : out std_logic_vector(31 downto 0);
        aluControlOut_tb : out std_logic_vector(3 downto 0);
        imm_genOut_tb : out std_logic_vector(31 downto 0);
        mainC_outALUsrc_tb : out std_logic
   );
end top_dataPath;

architecture Behavioral of top_dataPath is
-- declare component register (PC)
component register32bit is
    port (
        I : IN STD_LOGIC_VECTOR (31 DOWNTO 0);
        CLK, Reset, Set : IN STD_LOGIC;
        Q : OUT STD_LOGIC_VECTOR (31 DOWNTO 0)
    );
end component;
-- declare component instruction_memory
component instruction_memory is
    port(
        addr_in : in std_logic_vector(31 downto 0); 
        instr_out : out std_logic_vector(31 downto 0) 
    );
end component;
-- declare component Main_Control
component Main_Control is
    port(
        Opcode : in STD_LOGIC_VECTOR (6 downto 0); -- 7 bit Opcode inputs
        ALUSrc : out STD_LOGIC; -- outputs
        MemtoReg : out STD_LOGIC;
        RegWrite : out STD_LOGIC;
        MemRead : out STD_LOGIC;
        MemWrite : out STD_LOGIC;
        Branch : out STD_LOGIC;
        ALUOp : out STD_LOGIC_VECTOR (1 downto 0) -- 2 bit ALU
     );
end component;
-- declare component Regisiter_File
component Register_File is
    port(
        clk       : in  std_logic;
        reset     : in  std_logic;
        read_reg1 : in  std_logic_vector(4 downto 0); -- Address for read port 1
        read_reg2 : in  std_logic_vector(4 downto 0); -- Address for read port 2
        write_reg : in  std_logic_vector(4 downto 0); -- Address for write operation
        write_data: in  std_logic_vector(31 downto 0); -- Data to write
        write_en  : in  std_logic; -- Write enable
        data_out1 : out std_logic_vector(31 downto 0); -- Read data 1
        data_out2 : out std_logic_vector(31 downto 0)  -- Read data 2
     );
end component;
-- declare component imm_gen
component imm_gen is
    port(
        instr  : in  STD_LOGIC_VECTOR(31 downto 0);
        imm_out: out STD_LOGIC_VECTOR(31 downto 0)
    );
end component;
-- declare component data_memory
component data_memory is
    port(
        reset : in std_logic;
        clk : in std_logic;
        MW : in std_logic;
        addr_in : in std_logic_vector(31 downto 0); -- we use only 4 bits though here;
        data_in : in std_logic_vector(31 downto 0);
        data_out : out std_logic_vector(31 downto 0) 
      );
end component;
-- declare component ALU_Control
component ALU_Control is
    port(
        ALU_Op1 : in std_logic;  -- ALUOp bit 1
        ALU_Op2 : in std_logic;  -- ALUOp bit 0
        I_12 : in std_logic;  -- Funct3 bit 0
        I_13 : in std_logic;  -- Funct3 bit 1
        I_14 : in std_logic;  -- Funct3 bit 2
        I_25 : in std_logic;  -- Funct7 bits
        I_26 : in std_logic;
        I_27 : in std_logic;
        I_28 : in std_logic;
        I_29 : in std_logic;
        I_30 : in std_logic;
        I_31 : in std_logic;
        Operation : out std_logic_vector(3 downto 0) -- Fixed direction
     );
end component;
-- declare component ALU
component ALU is
    port(
         a : in std_logic_vector(31 downto 0);
         b : in std_logic_vector(31 downto 0);
         ALU_operation : in std_logic_vector(3 downto 0);
         result : out std_logic_vector(31 downto 0);
         carryout : out std_logic;
         overflow : out std_logic;
         zero : out std_logic
    );
end component;
-- declare component mux2to1_32bit
component mux2to1_32bit is
    port(
        in0, in1 : IN STD_LOGIC_VECTOR(31 downto 0);
        sel : IN STD_LOGIC;
        mux_out : OUT STD_LOGIC_VECTOR(31 downto 0)
      );
end component;
-- declare component adder32bit
component adder32bit is
    port(
          a: in STD_LOGIC_VECTOR(31 downto 0);
          b: in STD_LOGIC_VECTOR(31 downto 0);
          cin : in STD_LOGIC;
          s: out STD_LOGIC_VECTOR(31 downto 0);
          cout: out STD_LOGIC
      );
end component;

--signals for data path 
    --pc
    signal pc_out : std_logic_vector(31 downto 0);
    -- adder_1
    signal adder_1plus4 : std_logic_vector(31 downto 0);
    signal adder_1OutPut : std_logic_vector(31 downto 0);
    signal adder_1CarryOut : std_logic;
    signal adder_1CarryIn : std_logic;
    --instruction mem
    signal instruction : std_logic_vector(31 downto 0);  
    -- main control
    signal mainC_outBranch, mainC_outMemRead, mainC_outMemtoReg, mainC_outMemWrite, mainC_outALUsrc, mainC_outRegWrite : std_logic;
    signal mainC_outALUOp : std_logic_vector ( 1 downto 0);
    -- register file
    signal regFile_outData1, regFile_outData2 : std_logic_vector(31 downto 0);
    -- imm_gen
    signal imm_genOut : std_logic_vector(31 downto 0);
    -- mux_1
    signal mux1_out : std_logic_vector(31 downto 0);
    -- ALU_Control
    signal aluControlOut : std_logic_vector(3 downto 0);
    -- ALU
    signal aluOut : std_logic_vector(31 downto 0);
    signal aluCarryOut : std_logic;
    signal aluOverflow : std_logic;
    signal aluZeroOut : std_logic;
    -- adder_2
    signal adder_2OutPut : std_logic_vector(31 downto 0);
    signal adder_2CarryOut : std_logic;
    signal adder_2CarryIn : std_logic;
    -- mux_2
    signal mux2_out : std_logic_vector(31 downto 0);
    signal mux2_BranchAndZero : std_logic;
    -- data_memory
    signal data_memReadData : std_logic_vector(31 downto 0);
    -- mux_3
    signal mux3_out : std_logic_vector(31 downto 0);

begin
-- Prep signals
adder_1CarryIn <= '0';
adder_1plus4 <= X"00000001"; -- + 4
adder_2carryIn <= '0';
-- initialize PC
pc_register : register32bit
    port map(
        I => mux2_out, -- needs to be replaced by pc_plus_4 (Done)
        CLK => ClK,
        Reset => Reset,
        Set => '0',
        Q => pc_out
   );
-- initialize adder 1
adder_1 : adder32bit
    port map(
        a => pc_out, -- changed
        b => adder_1plus4,
        cin => adder_1CarryIn,
        s => adder_1OutPut,
        cout => adder_1CarryOut
   );
        
-- initialize instruction memory
instr_mem : instruction_memory
    port map(
        addr_in => pc_out,
        instr_out => instruction
    );
-- initialize main control
main_contr : Main_Control
    port map(
        Opcode => instruction(6 downto 0),
        ALUSrc => mainC_outALUsrc,
        MemtoReg => mainC_outMemtoReg,
        RegWrite => mainC_outRegWrite,
        MemRead => mainC_outMemRead,
        MemWrite => mainC_outMemWrite,
        Branch => mainC_outBranch,
        ALUOp => mainC_outALUOp
    );
-- initialize register file
reg_file : Register_File
    port map(
            clk => CLK,       
            reset => Reset,
            read_reg1 => instruction(19 downto 15),
            read_reg2 => instruction(24 downto 20),
            write_reg => instruction(11 downto 7),
            write_data => mux3_out, -- needs to be changed!!! (Done)
            write_en => mainC_outRegWrite,
            data_out1 => regFile_outData1,
            data_out2  => regFile_outData2
     );
-- initialize imm_gen
immediate_gen : imm_gen
    port map(
        instr => instruction,     
        imm_out => imm_genOut
    );
-- initialize mux_1
mux_1 : mux2to1_32bit
    port map(
        in0 => regFile_outData2,
        in1 => imm_genOut,
        sel => mainC_outALUsrc,
        mux_out => mux1_out
    );
-- initialize alu_control
alu_cont : ALU_Control
    port map(
        ALU_Op1 => mainC_outALUOp(1),
        ALU_Op2 => mainC_outALUOp(0),
        I_12 => instruction(12),
        I_13 => instruction(13),
        I_14 => instruction(14),
        I_25 => instruction(25),
        I_26 => instruction(26),
        I_27 => instruction(27),
        I_28 => instruction(28),
        I_29 => instruction(29),
        I_30 => instruction(30),
        I_31 => instruction(31),
        Operation => aluControlOut
    );
-- initialize alu
alu_main : ALU
    port map(
          a => regFile_outData1,
          b => mux1_out,
          ALU_operation => aluControlOut,
          result => aluOut,
          carryout => aluCarryOut,
          overflow => aluOverflow,
          zero => aluZeroOut
      );
-- initialize adder_2
adder_2 : adder32bit
    port map(
        a => pc_out,
        b => imm_genOut,
        cin => adder_2carryIn,
        s => adder_2OutPut,
        cout => adder_2CarryOut
      );
-- prep signal for mux_2
mux2_BranchAndZero <= mainC_outBranch AND aluZeroOut;
-- initialize mux_2
mux_2 : mux2to1_32bit
    port map(
        in0 => adder_1OutPut,
        in1 => adder_2OutPut,
        sel => mux2_BranchAndZero,
        mux_out => mux2_out
    );
-- initialize data_memory
data_mem : data_memory
    port map(
        reset => Reset,
        clk => CLK,
        MW => mainC_outMemWrite,
        addr_in => aluOut,
        data_in => regFile_outData2,
        data_out => data_memReadData
    );
-- initialize mux_3
mux_3 : mux2to1_32bit
    port map(
        in0 => aluOut,
        in1 => data_memReadData,
        sel => mainC_outMemtoReg,
        mux_out => mux3_out
    );
    
    --for TB
    PC_out_tb <= pc_out;
    MUX3_out_tb <= mux3_out;
    INSTRUCTION_tb <= instruction;
    ALU_out_tb <= aluOut;
    regFile_outData1_tb <= regFile_outData1;
    regFile_outData2_tb <= regFile_outData2;
    mux1_out_tb <= mux1_out;
    aluControlOut_tb <= aluControlOut;
    imm_genOut_tb <= imm_genOut;
    mainC_outALUsrc_tb <= mainC_outALUsrc;
    
    
end Behavioral;
