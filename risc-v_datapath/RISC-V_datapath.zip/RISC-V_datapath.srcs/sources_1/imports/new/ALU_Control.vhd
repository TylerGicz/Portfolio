library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity ALU_Control is
    Port ( 
        ALU_Op1 : in std_logic;  -- ALUOp bit 1
        ALU_Op2 : in std_logic;  -- ALUOp bit 0
        I_12 : in std_logic;  -- Funct3 bit 0
        I_13 : in std_logic;  -- Funct3 bit 1
        I_14 : in std_logic;  -- Funct3 bit 2
        I_25 : in std_logic;  -- Funct7 bits
        I_26 : in std_logic;
        I_27 : in std_logic;
        I_28 : in std_logic;
        I_29 : in std_logic;
        I_30 : in std_logic;
        I_31 : in std_logic;
        Operation : out std_logic_vector(3 downto 0) -- Fixed direction
    );
end ALU_Control;

architecture Behavioral of ALU_Control is
begin

    process(ALU_Op1, ALU_Op2, I_12, I_13, I_14, I_30)
    begin
        if (ALU_Op1 = '0' and ALU_Op2 = '0') then 
            Operation <= "0010";  -- ADD
        
        elsif (ALU_Op1 = '1' and I_30 = '0' and I_12 = '0' and I_13 = '0' and I_14 = '0') then 
            Operation <= "0010";  -- ADD
        
        elsif (ALU_Op1 = '1' and I_30 = '1' and I_12 = '0' and I_13 = '0' and I_14 = '0') then 
            Operation <= "0110";  -- SUB
        
        elsif (ALU_Op1 = '1' and I_30 = '0' and I_12 = '1' and I_13 = '1' and I_14 = '1') then 
            Operation <= "0000";  -- AND
        
        elsif (ALU_Op1 = '1' and I_30 = '0' and I_12 = '0' and I_13 = '1' and I_14 = '1') then 
            Operation <= "0001";  -- OR
        
        elsif (ALU_Op2 = '1') then 
            Operation <= "0110";  -- SUB
        

        end if;
    end process;

end Behavioral;
