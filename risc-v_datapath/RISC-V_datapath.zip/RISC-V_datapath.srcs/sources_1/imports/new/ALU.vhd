----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/21/2025 02:19:49 PM
-- Design Name: 
-- Module Name: ALU - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity ALU is
    Port ( 
        a : in std_logic_vector(31 downto 0);
        b : in std_logic_vector(31 downto 0);
        ALU_operation : in std_logic_vector(3 downto 0);
        result : out std_logic_vector(31 downto 0);
        carryout : out std_logic;
        overflow : out std_logic;
        zero : out std_logic
    );
end ALU;

architecture Behavioral of ALU is
--declare alu_1bit
component alu_1bit is
    port(
        a, b : IN STD_LOGIC; 
        ainvert, binvert : IN STD_LOGIC;
        carryIn : IN STD_LOGIC;
        less : IN STD_LOGIC;
        operation : IN STD_LOGIC_VECTOR(1 downto 0);
        result : OUT std_logic;
        carryOut : OUT std_logic
      );
end component;
--declare alu_1bit_MSB
component alu_1bit_MSB is
    port(
        a, b : IN STD_LOGIC;
        ainvert, binvert : IN STD_LOGIC;
        carryIn : IN STD_LOGIC;
        less : IN STD_LOGIC;
        operation : IN STD_LOGIC_VECTOR(1 DOWNTO 0);
        result : OUT STD_LOGIC;
        set : OUT STD_LOGIC;
        carryout : out std_logic;
        overflow : OUT STD_LOGIC
     );
end component;

    signal ainvert, binvert, cin : std_logic;
    signal op : std_logic_vector(1 downto 0);
    
    signal C0, C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, C11, C12 : STD_LOGIC;
    signal C13, C14, C15, C16, C17, C18, C19, C20, C21, C22, C23 : STD_LOGIC;
    signal C24, C25, C26, C27, C28, C29, C30, C31, C32 : STD_LOGIC;
    signal L0, S0 : std_logic; -- less, and set
    
    signal result_signal : std_logic_vector(31 downto 0);

begin

process(ALU_operation)
begin
    case ALU_operation is
        when "0000" => -- AND
            ainvert <= '0';
            binvert <= '0';
            op <= "00";
            cin <= '0';
        when "0001" => -- OR
            ainvert <= '0';
            binvert <= '0';
            op <= "01";
            cin <= '0';
        when "0010" => -- ADD
            ainvert <= '0';
            binvert <= '0';
            op <= "10";
            cin <= '0';
        when "0110" => -- SUB
            ainvert <= '0';
            binvert <= '1';
            op <= "10";
            cin <= '1';
        when "0111" => -- SLT
            ainvert <= '0';
            binvert <= '1';
            op <= "11";
            cin <= '1';
        when "1100" => -- NOR
            ainvert <= '1';
            binvert <= '1';
            op <= "00";
            cin <= '0';
        when others =>
            ainvert <= '0';
            binvert <= '0';
            op <= "00";
            cin <= '0';
    end case;
end process;

    L0 <= '0';
    C0 <= cin;
    ALU_1bit0: alu_1bit PORT MAP( a => a(0), b => b(0), carryIn => C0, result => result_signal(0), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C1, less => S0);
    ALU_1bit1: alu_1bit PORT MAP( a => a(1), b => b(1), carryIn => C1, result => result_signal(1), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C2, less => L0);    
    ALU_1bit2: alu_1bit PORT MAP( a => a(2), b => b(2), carryIn => C2, result => result_signal(2), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C3, less => L0);
    ALU_1bit3: alu_1bit PORT MAP( a => a(3), b => b(3), carryIn => C3, result => result_signal(3), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C4, less => L0);
    ALU_1bit4: alu_1bit PORT MAP( a => a(4), b => b(4), carryIn => C4, result => result_signal(4), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C5, less => L0);
    ALU_1bit5: alu_1bit PORT MAP( a => a(5), b => b(5), carryIn => C5, result => result_signal(5), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C6, less => L0);
    ALU_1bit6: alu_1bit PORT MAP( a => a(6), b => b(6), carryIn => C6, result => result_signal(6), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C7, less => L0);
    ALU_1bit7: alu_1bit PORT MAP( a => a(7), b => b(7), carryIn => C7, result => result_signal(7), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C8, less => L0);
    ALU_1bit8: alu_1bit PORT MAP( a => a(8), b => b(8), carryIn => C8, result => result_signal(8), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C9, less => L0);
    ALU_1bit9: alu_1bit PORT MAP( a => a(9), b => b(9), carryIn => C9, result => result_signal(9), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C10, less => L0);
    ALU_1bit10: alu_1bit PORT MAP( a => a(10), b => b(10), carryIn => C10, result => result_signal(10), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C11, less => L0);
    ALU_1bit11: alu_1bit PORT MAP( a => a(11), b => b(11), carryIn => C11, result => result_signal(11), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C12, less => L0);
    ALU_1bit12: alu_1bit PORT MAP( a => a(12), b => b(12), carryIn => C12, result => result_signal(12), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C13, less => L0);
    ALU_1bit13: alu_1bit PORT MAP( a => a(13), b => b(13), carryIn => C13, result => result_signal(13), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C14, less => L0);
    ALU_1bit14: alu_1bit PORT MAP( a => a(14), b => b(14), carryIn => C14, result => result_signal(14), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C15, less => L0);
    ALU_1bit15: alu_1bit PORT MAP( a => a(15), b => b(15), carryIn => C15, result => result_signal(15), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C16, less => L0);
    ALU_1bit16: alu_1bit PORT MAP( a => a(16), b => b(16), carryIn => C16, result => result_signal(16), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C17, less => L0);
    ALU_1bit17: alu_1bit PORT MAP( a => a(17), b => b(17), carryIn => C17, result => result_signal(17), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C18, less => L0);
    ALU_1bit18: alu_1bit PORT MAP( a => a(18), b => b(18), carryIn => C18, result => result_signal(18), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C19, less => L0);
    ALU_1bit19: alu_1bit PORT MAP( a => a(19), b => b(19), carryIn => C19, result => result_signal(19), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C20, less => L0);
    ALU_1bit20: alu_1bit PORT MAP( a => a(20), b => b(20), carryIn => C20, result => result_signal(20), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C21, less => L0);
    ALU_1bit21: alu_1bit PORT MAP( a => a(21), b => b(21), carryIn => C21, result => result_signal(21), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C22, less => L0);
    ALU_1bit22: alu_1bit PORT MAP( a => a(22), b => b(22), carryIn => C22, result => result_signal(22), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C23, less => L0);
    ALU_1bit23: alu_1bit PORT MAP( a => a(23), b => b(23), carryIn => C23, result => result_signal(23), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C24, less => L0);
    ALU_1bit24: alu_1bit PORT MAP( a => a(24), b => b(24), carryIn => C24, result => result_signal(24), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C25, less => L0);
    ALU_1bit25: alu_1bit PORT MAP( a => a(25), b => b(25), carryIn => C25, result => result_signal(25), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C26, less => L0);
    ALU_1bit26: alu_1bit PORT MAP( a => a(26), b => b(26), carryIn => C26, result => result_signal(26), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C27, less => L0);
    ALU_1bit27: alu_1bit PORT MAP( a => a(27), b => b(27), carryIn => C27, result => result_signal(27), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C28, less => L0);
    ALU_1bit28: alu_1bit PORT MAP( a => a(28), b => b(28), carryIn => C28, result => result_signal(28), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C29, less => L0);
    ALU_1bit29: alu_1bit PORT MAP( a => a(29), b => b(29), carryIn => C29, result => result_signal(29), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C30, less => L0);
    ALU_1bit30: alu_1bit PORT MAP( a => a(30), b => b(30), carryIn => C30, result => result_signal(30), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C31, less => L0);
    ALU_1bit_MSB0: alu_1bit_MSB PORT MAP( a => a(31), b => b(31), carryIn => C31, result => result_signal(31), ainvert => ainvert, binvert => binvert, operation => op, carryOut => C32, overflow => overflow, set => S0, less => L0);    
    result <= result_signal;
    carryout <= C32;
    -- Zero flag logic
        process(result_signal)
        begin
            if result_signal = x"00000000" then
                zero <= '1';
            else
                zero <= '0';
            end if;
        end process;
end Behavioral;
