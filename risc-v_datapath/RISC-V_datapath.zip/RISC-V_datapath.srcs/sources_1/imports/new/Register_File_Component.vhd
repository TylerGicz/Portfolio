library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Register_File is
    Port (
        clk       : in  std_logic;
        reset     : in  std_logic;
        read_reg1 : in  std_logic_vector(4 downto 0); -- Address for read port 1
        read_reg2 : in  std_logic_vector(4 downto 0); -- Address for read port 2
        write_reg : in  std_logic_vector(4 downto 0); -- Address for write operation
        write_data: in  std_logic_vector(31 downto 0); -- Data to write
        write_en  : in  std_logic; -- Write enable
        data_out1 : out std_logic_vector(31 downto 0); -- Read data 1
        data_out2 : out std_logic_vector(31 downto 0)  -- Read data 2
    );
end Register_File;

architecture Behavioral of Register_File is
    type reg_array is array (0 to 31) of std_logic_vector(31 downto 0); -- 32 registers, 32-bit each
    signal registers : reg_array := (others => (others => '0')); -- Initialize to 0


begin

    -- Asynchronous Read
    data_out1 <= registers(to_integer(unsigned(read_reg1)));
    data_out2 <= registers(to_integer(unsigned(read_reg2)));
    
    
-- Synchronous Write
    process(clk)
    begin
        if rising_edge(clk) then
            if reset = '1' then
                registers <= (others => (others => '0')); -- Ensure full reset
            elsif write_en = '1' then
                registers(to_integer(unsigned(write_reg))) <= write_data; -- Only write when write_en is '1'
            end if;
        end if;
    end process;
    end behavioral;
