library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;  -- Use numeric_std for to_integer()

entity Register_Read1 is
    Port (
        clk       : in  std_logic;
        reset     : in  std_logic;
        address   : in  std_logic_vector(4 downto 0); -- 5-bit address input
        data_out1 : out std_logic_vector(31 downto 0) -- 32-bit data output
    );
end Register_Read1;

architecture Behavioral of Register_Read1 is
    type reg_array is array (0 to 31) of std_logic_vector(31 downto 0); -- 32 registers, 32-bit each
    signal registers : reg_array := (
        x"00000000", x"00000001", x"00000002", x"00000003",
        x"00000004", x"00000005", x"00000006", x"00000007",
        x"00000008", x"00000009", x"0000000A", x"0000000B",
        x"0000000C", x"0000000D", x"0000000E", x"0000000F",
        x"00000010", x"00000011", x"00000012", x"00000013",
        x"00000014", x"00000015", x"00000016", x"00000017",
        x"00000018", x"00000019", x"0000001A", x"0000001B",
        x"0000001C", x"0000001D", x"0000001E", x"0000001F"
    );
begin
    process(clk, reset)
    begin
        if reset = '1' then
            data_out1 <= (others => '0');
        elsif rising_edge(clk) then
            data_out1 <= registers(to_integer(unsigned(address))); -- Corrected conversion
        end if;
    end process;
end Behavioral;
