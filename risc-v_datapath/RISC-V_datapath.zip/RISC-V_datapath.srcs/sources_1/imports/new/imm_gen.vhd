----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/30/2025 11:53:22 PM
-- Design Name: 
-- Module Name: imm_gen - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity imm_gen is
    Port (
        instr  : in  STD_LOGIC_VECTOR(31 downto 0);
        imm_out: out STD_LOGIC_VECTOR(31 downto 0)
    );
end imm_gen;

architecture Behavioral of imm_gen is
  
begin

    process(instr)
    begin
        case instr(6 downto 0) is
            when "0110011" => imm_out <= "00000000000000000000000000000000";
            when "0000011" => imm_out <= "00000000000000000000" & instr(31 downto 20);
            when "0100011" => imm_out <= "00000000000000000000" & instr(31 downto 25) & instr(11 downto 7);
            when "1100011" => imm_out <= "00000000000000000000" & instr(31) & instr(7) & instr(30 downto 25) & instr(11 downto 8);
            when others => imm_out <= (others => '0');
        end case;
    end process;

end Behavioral;