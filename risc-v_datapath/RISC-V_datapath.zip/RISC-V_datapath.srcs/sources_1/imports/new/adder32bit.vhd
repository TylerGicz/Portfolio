----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 03/31/2025 10:59:53 PM
-- Design Name: 
-- Module Name: adder32bit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity adder32bit is
    Port ( 
        a: in STD_LOGIC_VECTOR(31 downto 0);
        b: in STD_LOGIC_VECTOR(31 downto 0);
        cin : in STD_LOGIC;
        s: out STD_LOGIC_VECTOR(31 downto 0);
        cout: out STD_LOGIC
    );
end adder32bit;

architecture Behavioral of adder32bit is
--declare
    component full_adder is
        Port(
            x, y, cin: in  STD_LOGIC;
            sum, cout: out STD_LOGIC
        );
    end component;
    
    signal C0, C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, C11, C12 : STD_LOGIC;
    signal C13, C14, C15, C16, C17, C18, C19, C20, C21, C22, C23 : STD_LOGIC;
    signal C24, C25, C26, C27, C28, C29, C30, C31, C32 : STD_LOGIC;
begin
    C0 <= '0';
    FA0: full_adder PORT MAP( x => a(0), y => b(0), cin => C0, sum =>s(0), cout => C1);
    FA1: full_adder PORT MAP( x => a(1), y => b(1), cin => C1, sum =>s(1), cout => C2);
    FA2: full_adder PORT MAP( x => a(2), y => b(2), cin => C2, sum =>s(2), cout => C3);
    FA3: full_adder PORT MAP( x => a(3), y => b(3), cin => C3, sum =>s(3), cout => C4);
    FA4: full_adder PORT MAP( x => a(4), y => b(4), cin => C4, sum =>s(4), cout => C5);
    FA5: full_adder PORT MAP( x => a(5), y => b(5), cin => C5, sum =>s(5), cout => C6);
    FA6: full_adder PORT MAP( x => a(6), y => b(6), cin => C6, sum =>s(6), cout => C7);
    FA7: full_adder PORT MAP( x => a(7), y => b(7), cin => C7, sum =>s(7), cout => C8);
    FA8: full_adder PORT MAP( x => a(8), y => b(8), cin => C8, sum =>s(8), cout => C9);
    FA9: full_adder PORT MAP( x => a(9), y => b(9), cin => C9, sum =>s(9), cout => C10);
    FA10: full_adder PORT MAP( x => a(10), y => b(10), cin => C10, sum =>s(10), cout => C11);
    FA11: full_adder PORT MAP( x => a(11), y => b(11), cin => C11, sum =>s(11), cout => C12);
    FA12: full_adder PORT MAP( x => a(12), y => b(12), cin => C12, sum =>s(12), cout => C13);
    FA13: full_adder PORT MAP( x => a(13), y => b(13), cin => C13, sum =>s(13), cout => C14);
    FA14: full_adder PORT MAP( x => a(14), y => b(14), cin => C14, sum =>s(14), cout => C15);
    FA15: full_adder PORT MAP( x => a(15), y => b(15), cin => C15, sum =>s(15), cout => C16);
    FA16: full_adder PORT MAP( x => a(16), y => b(16), cin => C16, sum =>s(16), cout => C17);
    FA17: full_adder PORT MAP( x => a(17), y => b(17), cin => C17, sum =>s(17), cout => C18);
    FA18: full_adder PORT MAP( x => a(18), y => b(18), cin => C18, sum =>s(18), cout => C19);
    FA19: full_adder PORT MAP( x => a(19), y => b(19), cin => C19, sum =>s(19), cout => C20);
    FA20: full_adder PORT MAP( x => a(20), y => b(20), cin => C20, sum =>s(20), cout => C21);
    FA21: full_adder PORT MAP( x => a(21), y => b(21), cin => C21, sum =>s(21), cout => C22);
    FA22: full_adder PORT MAP( x => a(22), y => b(22), cin => C22, sum =>s(22), cout => C23);
    FA23: full_adder PORT MAP( x => a(23), y => b(23), cin => C23, sum =>s(23), cout => C24);
    FA24: full_adder PORT MAP( x => a(24), y => b(24), cin => C24, sum =>s(24), cout => C25);
    FA25: full_adder PORT MAP( x => a(25), y => b(25), cin => C25, sum =>s(25), cout => C26);
    FA26: full_adder PORT MAP( x => a(26), y => b(26), cin => C26, sum =>s(26), cout => C27);
    FA27: full_adder PORT MAP( x => a(27), y => b(27), cin => C27, sum =>s(27), cout => C28);
    FA28: full_adder PORT MAP( x => a(28), y => b(28), cin => C28, sum =>s(28), cout => C29);
    FA29: full_adder PORT MAP( x => a(29), y => b(29), cin => C29, sum =>s(29), cout => C30);
    FA30: full_adder PORT MAP( x => a(30), y => b(30), cin => C30, sum =>s(30), cout => C31);
    FA31: full_adder PORT MAP( x => a(31), y => b(31), cin => C31, sum =>s(31), cout => C32);
    cout <= C32;
end Behavioral;
