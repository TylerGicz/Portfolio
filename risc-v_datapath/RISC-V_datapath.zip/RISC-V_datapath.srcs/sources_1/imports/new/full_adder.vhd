----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 03/31/2025 10:58:20 PM
-- Design Name: 
-- Module Name: full_adder - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity full_adder is
  Port ( 
  x, y, cin :   in std_logic;
  sum, cout :   out std_logic);
end full_adder;

architecture Behavioral of full_adder is

begin
    sum <= ((x xor y) xor cin);
    cout <= ((x and y)  or (x and cin) or (y and cin));
end Behavioral;

