----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/21/2025 01:58:41 PM
-- Design Name: 
-- Module Name: alu_1bit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


ENTITY alu_1bit IS
	PORT (
    a, b : IN STD_LOGIC; 
    ainvert, binvert : IN STD_LOGIC;
    carryIn : IN STD_LOGIC;
    less : IN STD_LOGIC;
    operation : IN STD_LOGIC_VECTOR(1 downto 0);
	Result : OUT std_logic;
    carryOut : out std_logic
  );
END alu_1bit;


ARCHITECTURE dataflow OF alu_1bit IS	
--declare full_adder
component full_adder is
        Port(
            x, y, cin: in  STD_LOGIC;
            sum, cout: out STD_LOGIC
        );
    end component;
--declare signals to use
    signal in0, in1, in2: std_logic; --outputs of each gate (AND, OR, Adder) (less is already declared)
    signal muxa, muxb : std_logic; --outputs of multiplexters for bits a and b
    signal a_inv, b_inv : std_logic; -- inverted inputs a and b
    
BEGIN
    
    a_inv <= NOT a;
    b_inv <= NOT b;
    
    muxa <= a WHEN ainvert = '0' ELSE a_inv;
    muxb <= b WHEN binvert = '0' ELSE b_inv;
    
    in0 <= muxa AND muxb;
    in1 <= muxa OR muxb;
    
    FA0: full_adder port map (x=>muxa, y=>muxb, cin=>carryIn, sum=>in2, cout=>carryOut);
    
	Result <= 
	in0 WHEN operation = "00" ELSE
	in1 WHEN operation = "01" ELSE
	in2 WHEN operation = "10" ELSE
	less;
	
END dataflow ;
