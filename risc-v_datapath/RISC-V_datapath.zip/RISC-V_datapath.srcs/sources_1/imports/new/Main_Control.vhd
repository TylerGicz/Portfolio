----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 03/29/2025 10:37:12 PM
-- Design Name: 
-- Module Name: Main_Control - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Main_Control is
    Port (
        Opcode : in STD_LOGIC_VECTOR (6 downto 0); -- 7 bit Opcode inputs
        ALUSrc : out STD_LOGIC; -- outputs
        MemtoReg : out STD_LOGIC;
        RegWrite : out STD_LOGIC;
        MemRead : out STD_LOGIC;
        MemWrite : out STD_LOGIC;
        Branch : out STD_LOGIC;
        ALUOp : out STD_LOGIC_VECTOR (1 downto 0) -- 2 bit ALU
    );
end Main_Control;

architecture Behavioral of Main_Control is
begin
    process (Opcode)
    begin
        case Opcode is
            when "0110011" => -- R-Format instruction
                ALUSrc <= '0';
                MemtoReg <= '0';
                RegWrite <= '1';
                MemRead <= '0';
                MemWrite <= '0';
                Branch <= '0';
                ALUOp <= "10";
            when "0000011" => -- lw instructoin
                ALUSrc <= '1';
                MemtoReg <= '1';
                RegWrite <= '1';
                MemRead <= '1';
                MemWrite <= '0';
                Branch <= '0';
                ALUOp <= "00";
            when "0100011" => -- sw instruction
                ALUSrc <= '1';
                MemtoReg <= '0'; -- don't care x
                RegWrite <= '0';
                MemRead <= '0';
                MemWrite <= '1';
                Branch <= '0';
                ALUOp <= "00";
            when "1100011" => -- beq instruction
                ALUSrc <= '0';
                MemtoReg <= '0'; -- don't care x
                RegWrite <= '0';
                MemRead <= '0';
                MemWrite <= '0';
                Branch <= '1';
                ALUOp <= "01";
            when others => -- base case, everything 0
                ALUSrc <= '0';
                MemtoReg <= '0';
                RegWrite <= '0';
                MemRead <= '0';
                MemWrite <= '0';
                Branch <= '0';
                ALUOp <= "00";
        end case;
    end process;
end Behavioral;
