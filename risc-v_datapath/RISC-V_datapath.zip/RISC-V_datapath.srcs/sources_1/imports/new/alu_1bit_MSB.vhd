----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/21/2025 03:09:47 PM
-- Design Name: 
-- Module Name: alu_1bit_MSB - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY alu_1bit_MSB IS -- might need carryout
    PORT (
        a, b : IN STD_LOGIC;
        ainvert, binvert : IN STD_LOGIC;
        carryIn : IN STD_LOGIC;
        less : IN STD_LOGIC;
        operation : IN STD_LOGIC_VECTOR(1 DOWNTO 0);
        Result : OUT STD_LOGIC;
        set : OUT STD_LOGIC;
        overflow : OUT STD_LOGIC;
        carryOut : out std_logic
    );
END alu_1bit_MSB;

ARCHITECTURE dataflow OF alu_1bit_MSB IS
    COMPONENT full_adder IS
        PORT (
            x, y, cin : IN STD_LOGIC;
            sum, cout : OUT STD_LOGIC
        );
    END COMPONENT;

    SIGNAL in0, in1, in2 : STD_LOGIC;
    SIGNAL muxa, muxb : STD_LOGIC;
    SIGNAL a_inv, b_inv : STD_LOGIC;
    SIGNAL ovfcarry : STD_LOGIC;

BEGIN
    a_inv <= NOT a;
    b_inv <= NOT b;

    muxa <= a WHEN ainvert = '0' ELSE a_inv;
    muxb <= b WHEN binvert = '0' ELSE b_inv;

    in0 <= muxa AND muxb;
    in1 <= muxa OR muxb;

    FA0: full_adder PORT MAP (x => muxa, y => muxb, cin => carryIn, sum => in2, cout => ovfcarry);

    Result <=
        in0 WHEN operation = "00" ELSE
        in1 WHEN operation = "01" ELSE
        in2 WHEN operation = "10" ELSE
        less;

    overflow <= carryIn XOR ovfcarry;
    carryOut <= ovfcarry;
    set <= in2;

END dataflow;