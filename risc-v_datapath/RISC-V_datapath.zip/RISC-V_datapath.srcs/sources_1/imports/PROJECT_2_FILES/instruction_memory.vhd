-- this is a read only memory, where Instructions are stored

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;


entity instruction_memory is 
  port ( 
    addr_in : in std_logic_vector(31 downto 0); 
    instr_out : out std_logic_vector(31 downto 0) 
  );
end instruction_memory;


architecture behavioral_arch of instruction_memory is

begin	   
	
	instr_mem_process: process (addr_in) is
		variable var_addr : integer;
	begin 
		var_addr := conv_integer(addr_in(3 downto 0));
		case var_addr is
		    when 0  => instr_out <= X"00000000";
			when 1  => instr_out <= X"00A02303"; -- lw x6,  10(x0) -> x6 = 1
			when 2  => instr_out <= X"00B02383"; -- lw x7, 11(x0) -> x7 = 2
			when 3  => instr_out <= X"00D02E03"; -- lw x28, 13(x0) -> x28 = 3
			when 4  => instr_out <= X"00730EB3"; -- add x29, x6, x7 -> x29 = 1 + 2 = 3
			when 5  => instr_out <= X"00730F33"; -- add x30, x6, x7 -> x30 = 1 + 2 = 3
			when 6  => instr_out <= X"01DE0263"; -- BEQ x28, x29, 2 -- CHECK IF ERROR
			when 7  => instr_out <= X"01DE0F33"; -- add x30, x28, x29 -> t5 = t3 + t4
			when 8  => instr_out <= X"01D02723"; -- sw x29, 14(x0) 
			when 9  => instr_out <= X"00E02F83"; -- lw x31, 14(x0)
			when 10 => instr_out <= X"00000000";
			when 11 => instr_out <= X"00000000";
			when 12 => instr_out <= X"00000000";
			when 13 => instr_out <= X"00000000";
			when 14 => instr_out <= X"00000000";
			when 15 => instr_out <= X"00000000";
			when others =>  instr_out <= X"00000000";
		end case;
	end process;
  
end behavioral_arch;
