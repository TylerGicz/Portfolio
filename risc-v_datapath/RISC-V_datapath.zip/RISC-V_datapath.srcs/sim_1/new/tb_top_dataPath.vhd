----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/04/2025 12:49:59 PM
-- Design Name: 
-- Module Name: tb_top_dataPath - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_top_dataPath is
end tb_top_dataPath;

architecture Behavioral of tb_top_dataPath is

    signal tb_CLK : std_logic := '0';
    signal tb_Reset : std_logic := '1';  -- Start with reset high

    signal tb_PC_out    : std_logic_vector(31 downto 0);
    signal tb_MUX3_out  : std_logic_vector(31 downto 0);
    signal tb_instruction_out : std_logic_vector(31 downto 0);
    signal tb_ALU_out : std_logic_vector (31 downto 0);
    signal tb_aluControlOut : std_logic_vector(3 downto 0);
    signal tb_mux1_out : std_logic_vector(31 downto 0);
    signal tb_regFile_outData1 : std_logic_vector(31 downto 0);
    signal tb_regFile_outData2 : std_logic_vector(31 downto 0);
    signal tb_imm_genOut : std_logic_vector(31 downto 0);
    signal tb_mainC_outALUsrc : std_logic;
    
    
    -- Declare datapath component
    component top_dataPath
        port (
            CLK   : in std_logic;
            Reset : in std_logic;
            -- for TB
            PC_out_tb : out std_logic_vector(31 downto 0);  -- expose PC
            MUX3_out_tb : out std_logic_vector(31 downto 0); -- expose mux3 output
            INSTRUCTION_tb : out std_logic_vector(31 downto 0); 
            ALU_out_tb : out std_logic_vector(31 downto 0);
            regFile_outData1_tb : out std_logic_vector(31 downto 0);
            regFile_outData2_tb : out std_logic_vector(31 downto 0);
            mux1_out_tb : out std_logic_vector(31 downto 0);
            aluControlOut_tb : out std_logic_vector(3 downto 0);
            imm_genOut_tb : out std_logic_vector(31 downto 0);
            mainC_outALUsrc_tb : out std_logic
        );
    end component;

begin

    -- Instantiate datapath
    ddp : top_dataPath
        port map (
            CLK   => tb_CLK,
            Reset => tb_Reset,
            PC_out_tb   => tb_PC_out,
            MUX3_out_tb => tb_MUX3_out,
            INSTRUCTION_tb => tb_instruction_out,
            ALU_out_tb => tb_ALU_out,
            regFile_outData1_tb => tb_regFile_outData1,
            regFile_outData2_tb => tb_regFile_outData2,
            mux1_out_tb => tb_mux1_out,
            aluControlOut_tb => tb_aluControlOut,
            imm_genOut_tb => tb_imm_genOut,
            mainC_outALUsrc_tb => tb_mainC_outALUsrc
        );

    -- Clock generation
    clock_process : process
    begin
        while true loop
            tb_CLK <= '0';
            wait for 10 ns;
            tb_CLK <= '1';
            wait for 10 ns;
        end loop;
    end process;

    -- Reset signal process: hold high for 4 rising edges of the clock
    reset_process : process
        variable cycle_count : integer := 0;
    begin
        while cycle_count < 4 loop
            wait until rising_edge(tb_CLK);
            cycle_count := cycle_count + 1;
        end loop;

        tb_Reset <= '0';

        wait;
    end process;

end Behavioral;