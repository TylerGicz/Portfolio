----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/08/2025 05:06:49 PM
-- Design Name: 
-- Module Name: tb_immgen - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity imm_gen_tb is
end imm_gen_tb;

architecture Behavioral of imm_gen_tb is
    -- DUT ports
    signal instr   : STD_LOGIC_VECTOR(31 downto 0);
    signal imm_out : STD_LOGIC_VECTOR(31 downto 0);
    signal opcode_dbg : STD_LOGIC_VECTOR(6 downto 0);

    -- Component Declaration for the DUT
    component imm_gen
        Port (
            instr   : in  STD_LOGIC_VECTOR(31 downto 0);
            imm_out : out STD_LOGIC_VECTOR(31 downto 0)
        );
    end component;

begin
    -- Instantiate the DUT
    uut: imm_gen
        port map (
            instr   => instr,
            imm_out => imm_out
        );

    -- Stimulus process
    stim_proc: process
    begin
        -- lw x6,  10(x0) -> x6 = 1         (10)
        instr <= X"00A02303"; 
        wait for 10 ns;

        -- lw x7, 11(x0) -> x7 = 2          (11)
        instr <= X"00B02383"; 
        wait for 10 ns;

        -- lw x28, 13(x0) -> x28 = 3        (13)
        instr <= X"00D02E03"; 
        wait for 10 ns;

        -- BEQ x28, x29, 2                  (2)
        instr <= X"01DE0263"; 
        wait for 10 ns;
        
        -- sw x29, 14(x0)                   (14)
        instr <= X"01D02723"; 
        wait for 10 ns;
        
        -- lw x31, 14(x0)                   (14)
        instr <= X"00E02F83"; 
        wait for 10 ns;
        
        -- Unknown opcode (should output zero)
        instr <= (others => '0');
        wait for 10 ns;

        wait;
    end process;
end Behavioral;